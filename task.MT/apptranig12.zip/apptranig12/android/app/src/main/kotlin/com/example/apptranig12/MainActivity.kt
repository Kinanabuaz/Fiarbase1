package com.example.apptranig12

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
