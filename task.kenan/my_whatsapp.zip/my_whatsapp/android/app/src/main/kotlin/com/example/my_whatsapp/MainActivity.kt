package com.example.my_whatsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
